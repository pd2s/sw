# [basu]

The sd-bus library, extracted from systemd.

Some projects rely on the sd-bus library for DBus support. However not all
systems have systemd or elogind installed. This library provides just sd-bus
(and the `busctl` utility).

Feel free to join the IRC channel: #emersion on Libera Chat.

Report bugs on the [issue tracker] and send patches on the [mailing list].

[basu]: https://sr.ht/~emersion/basu
[issue tracker]: https://todo.sr.ht/~emersion/basu
[mailing list]: https://lists.sr.ht/~emersion/public-inbox
