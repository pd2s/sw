/* SPDX-License-Identifier: LGPL-2.1+ */
#pragma once

const char *capability_to_name(int id);
