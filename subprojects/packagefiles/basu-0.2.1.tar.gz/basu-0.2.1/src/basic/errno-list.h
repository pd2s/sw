/* SPDX-License-Identifier: LGPL-2.1+ */
#pragma once

const char *errno_to_name(int id);
int errno_from_name(const char *name);
