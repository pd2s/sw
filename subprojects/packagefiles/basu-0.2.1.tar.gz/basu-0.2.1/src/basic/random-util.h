/* SPDX-License-Identifier: LGPL-2.1+ */
#pragma once

#include <stdint.h>

int random_bytes(void *p, size_t n);

