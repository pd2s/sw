/* SPDX-License-Identifier: LGPL-2.1+ */
#pragma once

int log_level_to_string_alloc(int i, char **s);
int log_level_from_string(const char *s);

